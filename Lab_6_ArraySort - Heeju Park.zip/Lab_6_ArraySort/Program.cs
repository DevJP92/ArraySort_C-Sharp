﻿/*
This program is incomplete. Your job is to update the classes and the main program
to allow Baseball players to be sorted based on a  criteria the user selects from
a menu that you show to the user. The user may want to see the list of baseball
players sorted alphabetically, from smallest to biggest salary, or from smallest
number of hit to biggest hit statistics 

Hint:  
Review Week 8 (Chapter 7) slides and see which one of IComparable, IComparable<T>,
IComparer, IComparer<T> interfaces your classes in the program should implement to be able to use Array.Sort method in .NET
You can modify the given classes in the program and add a new class(es) as you find appropriate
*/

using System;
using System.Collections.Generic;

namespace Lab_6_ArraySort
{
    public abstract class Player: IComparable<Player>
    { 
        public string Name { get; set; }
        public double Salary { get; set; }
        public override string ToString() => $"{ Name } with salary of ${ Salary }";
        public void displayNameNSalary()
        {
            Console.WriteLine($"{ Name } with salary of ${ Salary }");
        }
        public abstract void displayStatistics();

        public int CompareTo(Player other)
        {
            if (other == null) throw new ArgumentNullException("other");
            return this.Name.CompareTo(other.Name);
        }
    }

    public class BaseballPlayer : Player, IComparable<BaseballPlayer>
    {
        public int AtBats { get; set; }
        public int HomeRuns { get; set; }
        public int Hits { get; set; }

        public override void displayStatistics()

        {
            Console.WriteLine($"At Bats: { AtBats } \nHome Runs: {  HomeRuns }\nHits: { Hits }");
        }


        public int CompareTo(BaseballPlayer other)
        {
            if (other == null) throw new ArgumentNullException("other");
            return this.Hits.CompareTo(other.Hits);
        }
    }

    public enum PersonCompareType
    {
        Name,
        Salary,
        Hits
    }

    public class PersonComparer : IComparer<BaseballPlayer>
    {
        private PersonCompareType _compareType;

        public PersonComparer(PersonCompareType compareType) =>
            _compareType = compareType;

        #region IComparer<Person> Members
        public int Compare(BaseballPlayer x, BaseballPlayer y)
        {
            if (x is null && y is null) return 0;
            if (x is null) return 1;
            if (y is null) return -1;

            switch (_compareType)
            {
                case PersonCompareType.Name:
                    return x.Name.CompareTo(y.Name);
                case PersonCompareType.Salary:
                    return x.Salary.CompareTo(y.Salary);
                case PersonCompareType.Hits:
                    return x.Hits.CompareTo(y.Hits);
                default:
                    throw new ArgumentException("unexpected compare type");
            }
        }
    }

    #endregion
    class Program
    {
        static void Main()
        {

            // create a one dimensional array of baseball
            // players with size of 100
            var playerArray = new BaseballPlayer[100];

            // add three baseball players to the array
            playerArray[0] = new BaseballPlayer() {
                Name = "Mike Trout",
                Salary = 33.25,
                AtBats = 470,
                HomeRuns = 45,
                Hits = 137
            };

            playerArray[1] = new BaseballPlayer()
            {
                Name = "Christian Yelich",
                Salary = 7,
                AtBats = 489,
                HomeRuns = 44,
                Hits = 161
            };

            playerArray[2] = new BaseballPlayer()
            {
                Name = "Cody Bellinger",
                Salary = 11.5,
                AtBats = 558,
                HomeRuns = 47,
                Hits = 170
            };


            // show menu to the user
            // 1. sort players based on salary and display
            // 2. sort players based on hits and display
            // 3. sort players based on name and display
        
            Console.WriteLine("Select the following\n");
            Console.WriteLine("1. sort players based on salary and display\n" +
                "2. sort players based on hits and display\n" +
                "3. sort players based on name and display");


            // ask the user what option they want from 
            // the menu and accordingly display all the information 
            // of the baseball players in that specific order
            //...

            string caseSwitch = Console.ReadLine();

            switch (caseSwitch)
            {
                case "1":
                    Array.Sort(playerArray,
                            new PersonComparer(PersonCompareType.Salary));
                    for (int i = 0; i < 3; i++)
                    {
                        playerArray[i].displayNameNSalary();
                        playerArray[i].displayStatistics();
                   
                    }
                    break;
                case "2":
                    Array.Sort(playerArray,
                           new PersonComparer(PersonCompareType.Hits));
                    for (int i = 0; i < 3; i++)
                    {
                        playerArray[i].displayNameNSalary();
                        playerArray[i].displayStatistics();
                    }
                    break;

                case "3":
                    Array.Sort(playerArray,
                               new PersonComparer(PersonCompareType.Name));
                    for (int i = 0; i < 3; i++)
                    {
                        playerArray[i].displayNameNSalary();
                        playerArray[i].displayStatistics();
                    }
                    break;

                default:
                    Console.WriteLine("Choose between 1-3.");
                    Console.ReadLine();
                    break;
            }

        }

    }

}

